import { useState } from 'react'
import './App.css'
import ApiCalls from './components/ApiCalls';
import PasswordStrength from './components/PasswordStrength';


function App() {

  return (
    <>
      {/* <ApiCalls /> */}
      <PasswordStrength />
    </>
  )
}

export default App
