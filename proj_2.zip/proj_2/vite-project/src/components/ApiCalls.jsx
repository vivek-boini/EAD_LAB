import { useState,useEffect } from "react";

const ApiCalls = () => {
    const URL="https://jsonplaceholder.typicode.com/users";
    const [print, setPrint]=useState([]);
    const getData=async(api)=>{
        const response=await fetch(api);
        const data=await response.json();
        console.log(data);
        setPrint(data);
    }

    useEffect(()=>{
        getData(URL);
    },[])
    
  return (
    <div>
      {print.map((item) => (
        <div key={item.id}>
          <h1>{item.name}</h1>
            <p> {item.email}</p>
            <p>{item.username}</p>
          <address> {item.address.street}, {item.address.suite}, {item.address.city}, {item.address.zipcode}</address>
        </div>
      ))}
    </div>
    )
}

export default ApiCalls;