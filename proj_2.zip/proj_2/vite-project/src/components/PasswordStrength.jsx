import { useState } from "react";

const PasswordStrength = () => {
    const [password, setPassword] = useState("");
    const [strength, setStrength] = useState("");

    const pass_regex=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    const evaluate=(password)=>{
        if(!password) return "";
        if(password.length<6) return "weak password";
        if(pass_regex.test(password)) return "Strong password";
        return "Moderate password";
    }

    const handleChange=(event)=>{
        const pass=event.target.value;
        setPassword(pass);
        setStrength(evaluate(pass));
    }

    return(
        <>
        <h1>Password Strength Checker</h1>
        <input type="text" onChange={handleChange}/>
        <p>{strength}</p>
        </>
    )
}

export default PasswordStrength;