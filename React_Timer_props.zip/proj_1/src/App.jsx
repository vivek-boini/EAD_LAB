import { useEffect, useState } from 'react'
import './App.css'
import Media from './Media'

function App() {
  const [time, setTime] = useState(0)
  const [running, setRunning] = useState(false)

  useEffect(() => {
  if(!running) return
  const interval = setInterval(() => {
    setTime((time) => time + 1)
  }, 1000)
  return () => clearInterval(interval)
}, [running])

const start=()=>{ setRunning(true) }
const stop=()=>{ setRunning(false) }
const reset=()=>{ setRunning(false) , setTime(0) }
  return(
    <div className="App">

      {/* Timer */}
      <div className='timer'>
        <h1>Stopwatch</h1>
        <button onClick={start}>Start</button>
        <button onClick={stop}>Stop</button>
        <button onClick={reset}>Reset</button>
        <h1>{time}</h1>
      </div>

      <hr />

      {/* Use of props in React */}
      <div className='props'>
        <h1>Props in React</h1>
        <Media name="John" age={30} profession="Developer" location="India" />
        <Media name="Ram" age={25} profession="Designer" location="India" />
        <Media name="Sam" age={28} profession="Manager" location="USA" />
      </div>
    </div>
  )
}

export default App
