import React from "react";

export default function Media(props) {
    return(
        <div>
            <h2>Name: {props.name}</h2> <br />
            Age: {props.age} <br />
            Profession: {props.profession} <br />
            Location: {props.location} <br />
        </div>
    );
}